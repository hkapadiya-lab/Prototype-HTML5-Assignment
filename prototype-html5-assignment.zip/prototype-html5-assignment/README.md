# Prototype HTML5 Assignment

A Pen created on CodePen.

Original URL: [https://codepen.io/hkapadiya-lab/pen/myVPROX](https://codepen.io/hkapadiya-lab/pen/myVPROX).

